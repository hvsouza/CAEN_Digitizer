/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../move_files/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[60];
    char stringdata0[627];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(35, 0), // ""
QT_MOC_LITERAL(36, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(60, 26), // "on_button_movefile_clicked"
QT_MOC_LITERAL(87, 28), // "on_button_movefile_5_clicked"
QT_MOC_LITERAL(116, 28), // "on_button_movefile_2_clicked"
QT_MOC_LITERAL(145, 30), // "on_pushButtonRecompile_clicked"
QT_MOC_LITERAL(176, 22), // "on_lock_folder_clicked"
QT_MOC_LITERAL(199, 7), // "checked"
QT_MOC_LITERAL(207, 18), // "enable_and_trigger"
QT_MOC_LITERAL(226, 10), // "QCheckBox*"
QT_MOC_LITERAL(237, 3), // "myt"
QT_MOC_LITERAL(241, 17), // "setEnabledTrigger"
QT_MOC_LITERAL(259, 18), // "setDisabledTrigger"
QT_MOC_LITERAL(278, 26), // "on_externaltrigger_clicked"
QT_MOC_LITERAL(305, 18), // "on_enable1_clicked"
QT_MOC_LITERAL(324, 18), // "on_enable2_clicked"
QT_MOC_LITERAL(343, 18), // "on_enable3_clicked"
QT_MOC_LITERAL(362, 18), // "on_enable4_clicked"
QT_MOC_LITERAL(381, 18), // "on_enable5_clicked"
QT_MOC_LITERAL(400, 18), // "on_enable6_clicked"
QT_MOC_LITERAL(419, 18), // "on_enable7_clicked"
QT_MOC_LITERAL(438, 18), // "on_enable8_clicked"
QT_MOC_LITERAL(457, 33), // "on_FileTypeSet_currentTextCha..."
QT_MOC_LITERAL(491, 4), // "arg1"
QT_MOC_LITERAL(496, 31), // "on_pushButton_SetConfig_clicked"
QT_MOC_LITERAL(528, 31), // "on_button_save_config_2_clicked"
QT_MOC_LITERAL(560, 29), // "on_button_save_config_clicked"
QT_MOC_LITERAL(590, 36) // "on_samplingRate_2_currentText..."

    },
    "MainWindow\0on_pushButton_2_clicked\0\0"
    "on_pushButton_4_clicked\0"
    "on_button_movefile_clicked\0"
    "on_button_movefile_5_clicked\0"
    "on_button_movefile_2_clicked\0"
    "on_pushButtonRecompile_clicked\0"
    "on_lock_folder_clicked\0checked\0"
    "enable_and_trigger\0QCheckBox*\0myt\0"
    "setEnabledTrigger\0setDisabledTrigger\0"
    "on_externaltrigger_clicked\0"
    "on_enable1_clicked\0on_enable2_clicked\0"
    "on_enable3_clicked\0on_enable4_clicked\0"
    "on_enable5_clicked\0on_enable6_clicked\0"
    "on_enable7_clicked\0on_enable8_clicked\0"
    "on_FileTypeSet_currentTextChanged\0"
    "arg1\0on_pushButton_SetConfig_clicked\0"
    "on_button_save_config_2_clicked\0"
    "on_button_save_config_clicked\0"
    "on_samplingRate_2_currentTextChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      24,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  158,    2, 0x08,    1 /* Private */,
       3,    0,  159,    2, 0x08,    2 /* Private */,
       4,    0,  160,    2, 0x08,    3 /* Private */,
       5,    0,  161,    2, 0x08,    4 /* Private */,
       6,    0,  162,    2, 0x08,    5 /* Private */,
       7,    0,  163,    2, 0x08,    6 /* Private */,
       8,    1,  164,    2, 0x08,    7 /* Private */,
      10,    2,  167,    2, 0x08,    9 /* Private */,
      13,    1,  172,    2, 0x08,   12 /* Private */,
      14,    1,  175,    2, 0x08,   14 /* Private */,
      15,    1,  178,    2, 0x08,   16 /* Private */,
      16,    1,  181,    2, 0x08,   18 /* Private */,
      17,    1,  184,    2, 0x08,   20 /* Private */,
      18,    1,  187,    2, 0x08,   22 /* Private */,
      19,    1,  190,    2, 0x08,   24 /* Private */,
      20,    1,  193,    2, 0x08,   26 /* Private */,
      21,    1,  196,    2, 0x08,   28 /* Private */,
      22,    1,  199,    2, 0x08,   30 /* Private */,
      23,    1,  202,    2, 0x08,   32 /* Private */,
      24,    1,  205,    2, 0x08,   34 /* Private */,
      26,    0,  208,    2, 0x08,   36 /* Private */,
      27,    0,  209,    2, 0x08,   37 /* Private */,
      28,    0,  210,    2, 0x08,   38 /* Private */,
      29,    1,  211,    2, 0x08,   39 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 11,    9,   12,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   25,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_2_clicked(); break;
        case 1: _t->on_pushButton_4_clicked(); break;
        case 2: _t->on_button_movefile_clicked(); break;
        case 3: _t->on_button_movefile_5_clicked(); break;
        case 4: _t->on_button_movefile_2_clicked(); break;
        case 5: _t->on_pushButtonRecompile_clicked(); break;
        case 6: _t->on_lock_folder_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 7: _t->enable_and_trigger((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QCheckBox*>>(_a[2]))); break;
        case 8: _t->setEnabledTrigger((*reinterpret_cast< std::add_pointer_t<QCheckBox*>>(_a[1]))); break;
        case 9: _t->setDisabledTrigger((*reinterpret_cast< std::add_pointer_t<QCheckBox*>>(_a[1]))); break;
        case 10: _t->on_externaltrigger_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 11: _t->on_enable1_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 12: _t->on_enable2_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 13: _t->on_enable3_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 14: _t->on_enable4_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 15: _t->on_enable5_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 16: _t->on_enable6_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 17: _t->on_enable7_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 18: _t->on_enable8_clicked((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 19: _t->on_FileTypeSet_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 20: _t->on_pushButton_SetConfig_clicked(); break;
        case 21: _t->on_button_save_config_2_clicked(); break;
        case 22: _t->on_button_save_config_clicked(); break;
        case 23: _t->on_samplingRate_2_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QCheckBox* >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QCheckBox* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QCheckBox* >(); break;
            }
            break;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<QCheckBox *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QCheckBox *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QCheckBox *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 24)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 24;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 24)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 24;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
